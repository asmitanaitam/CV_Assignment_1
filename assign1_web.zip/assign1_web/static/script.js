let points = [];
let canvas, ctx;

window.onload = function() {
    canvas = document.getElementById('imageCanvas');
    ctx = canvas.getContext('2d');

    document.getElementById('imageUpload').addEventListener('change', function(event) {
        let reader = new FileReader();
        reader.onload = function() {
            let img = new Image();
            img.onload = function() {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0);
                points = [];  // Reset points on new image
            };
            img.src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    });

    canvas.addEventListener('click', function(event) {
        if (points.length < 2) {
            points.push([event.offsetX, event.offsetY]);
            ctx.fillStyle = 'red';
            ctx.beginPath();
            ctx.arc(event.offsetX, event.offsetY, 5, 0, 2 * Math.PI);
            ctx.fill();
        }
    });
};

function sendData() {
    if (points.length === 2) {
        let canvas = document.getElementById('imageCanvas');
        canvas.toBlob(function(blob) {
            let reader = new FileReader();
            reader.onloadend = function() {
                $.ajax({
                    url: '/calculate',
                    method: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        image: reader.result,
                        points: points
                    }),
                    success: function(response) {
                        document.getElementById('dimensionDisplay').textContent =
                            'The dimension in millimeters is: ' + response.dimensions.toFixed(2) + ' mm';
                    }
                });
            };
            reader.readAsDataURL(blob);
        });
    } else {
        alert('Please select exactly two points on the image.');
    }
}

function refreshPage() {
    window.location.reload();
}
