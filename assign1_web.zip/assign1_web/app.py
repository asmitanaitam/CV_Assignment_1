from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
from io import BytesIO
import base64

app = Flask(__name__)

def calculate_dimensions(image, points):
    # Dummy function for calculating dimensions
    # Assume points are [(x1, y1), (x2, y2)]
    # Calculate the distance in pixels
    pixel_distance = np.linalg.norm(np.array(points[0]) - np.array(points[1]))
    return pixel_distance  # Placeholder for real-world distance calculation

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    image_data = data['image']
    points = data['points']
    
    # Decode image
    image_encoded = image_data.split(",")[1]
    image_bytes = base64.b64decode(image_encoded)
    image = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    
    # Calculate dimensions
    dimensions = calculate_dimensions(image, points)
    
    return jsonify({'dimensions': dimensions})

if __name__ == '__main__':
    app.run(debug=True)
